from django.db import models
from django.core.validators import MinValueValidator
from decimal import Decimal
from django.forms import ValidationError
from django.utils import timezone
from datetime import timedelta

class Employee(models.Model):
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]
    
    EMP_TYPE_CHOICES = [
        ('Regular', 'Regular'),
        ('Contract', 'Contract'),
        ('Others', 'Others'),
    ]
    
    name = models.CharField(max_length=255)
    tamil_name = models.CharField(max_length=255)
    joining_date = models.DateField()
    emp_type = models.CharField(max_length=100, choices=EMP_TYPE_CHOICES)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    image_url = models.URLField(max_length=500, blank=True, null=True)
    contact = models.CharField(max_length=20)
    status = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'xe_employee'

    def __str__(self):
        return self.name
    
class Merchant(models.Model):

    PAYMENT_TERMS_CHOICES = [
        ('Cash', 'Cash'),
        ('Card', 'Card'),
        ('UPI', 'UPI'),
        ('Online', 'Online'),
    ]

    name = models.CharField(max_length=255)
    address = models.TextField()
    payment_terms = models.CharField(max_length=100, choices=PAYMENT_TERMS_CHOICES)
    contact = models.CharField(max_length=15, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'xe_merchant'

    def __str__(self):
        return self.name

class FarmSegment(models.Model):
    farm_name = models.CharField(max_length=255, verbose_name="Farm Name")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'farm_segments'
        ordering = ['-created_at']
        verbose_name = 'Farm Segment'
        verbose_name_plural = 'Farm Segments'
    
    def __str__(self):
        return self.farm_name
    
class Crop(models.Model):
    crop_name = models.CharField(max_length=255, verbose_name="Crop Name")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'xe_crops'
        ordering = ['-created_at']
        verbose_name = 'Crop'
        verbose_name_plural = 'Crops'
    
    def __str__(self):
        return self.crop_name
    
class CropVariant(models.Model):
    UNIT_CHOICES = [
        ('Pieces', 'Pieces'),
        ('Bunch', 'Bunch'),
        ('Pack', 'Pack'),
    ]
    
    crop = models.ForeignKey(Crop, on_delete=models.CASCADE, related_name='variants')
    crop_variant = models.CharField(max_length=100)
    unit = models.CharField(max_length=20, choices=UNIT_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'xe_crop_variants'
        unique_together = ['crop', 'crop_variant']  # Prevent duplicate variants for same crop

    def __str__(self):
        return f"{self.crop.crop_name} - {self.crop_variant}"

class Yield(models.Model):
    crop = models.ForeignKey(Crop, on_delete=models.CASCADE, related_name='yields')
    harvest_date = models.DateTimeField()
    bill_url = models.URLField(max_length=500, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'xe_yields'
        ordering = ['-created_at']
        verbose_name = 'Yield'
        verbose_name_plural = 'Yields'
    
    def __str__(self):
        return f"{self.crop.crop_name} - {self.harvest_date.strftime('%Y-%m-%d')}"

class YieldFarmSegment(models.Model):
    """Junction table for yield and farm segments (many-to-many relationship)"""
    yield_record = models.ForeignKey(Yield, on_delete=models.CASCADE, related_name='yield_farm_segments')
    farm_segment = models.ForeignKey(FarmSegment, on_delete=models.CASCADE, related_name='yield_farm_segments')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'xe_yield_farm_segments'
        unique_together = ['yield_record', 'farm_segment']
    
    def __str__(self):
        return f"{self.yield_record} - {self.farm_segment.farm_name}"

class YieldVariant(models.Model):
    """Individual variant quantities for each yield record"""
    yield_record = models.ForeignKey(Yield, on_delete=models.CASCADE, related_name='yield_variants')
    crop_variant = models.ForeignKey(CropVariant, on_delete=models.CASCADE, related_name='yield_variants')
    quantity = models.DecimalField(max_digits=10, decimal_places=2)
    unit = models.CharField(max_length=20)  # Store the unit used at time of yield
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'xe_yield_variants'
        unique_together = ['yield_record', 'crop_variant']
    
    def __str__(self):
        return f"{self.yield_record} - {self.crop_variant.crop_variant}: {self.quantity} {self.unit}"

class Sale(models.Model):
    PAYMENT_MODE_CHOICES = [
        ('Cash', 'Cash'),
        ('Card', 'Card'),
        ('UPI', 'UPI'),
        ('Online', 'Online'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
    ]
    
    merchant = models.ForeignKey(Merchant, on_delete=models.CASCADE, related_name='sales')
    yield_record = models.ForeignKey(Yield, on_delete=models.CASCADE, related_name='sales')
    payment_mode = models.CharField(max_length=20, choices=PAYMENT_MODE_CHOICES)
    harvest_date = models.DateTimeField()
    bill_url = models.URLField(max_length=500, blank=True, null=True)
    
    # Financial fields
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    commission = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    lorry_rent = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    cooly_charges = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    total_deductions = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    total_calculated_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    final_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0, validators=[MinValueValidator(Decimal('0'))])
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'xe_sales'
        ordering = ['-created_at']
        verbose_name = 'Sale'
        verbose_name_plural = 'Sales'
    
    def __str__(self):
        return f"Sale {self.id} - {self.merchant.name} - ₹{self.final_amount}"
    
    def save(self, *args, **kwargs):
        # Auto-calculate total deductions and final amount
        self.total_deductions = self.commission + self.lorry_rent + self.cooly_charges
        self.final_amount = self.total_calculated_amount - self.total_deductions
        super().save(*args, **kwargs)

class SaleVariant(models.Model):
    """Individual variant sales data for each sale"""
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name='sale_variants')
    crop_variant = models.ForeignKey(CropVariant, on_delete=models.CASCADE, related_name='sale_variants')
    quantity = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    amount_per_unit = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    unit = models.CharField(max_length=20)  # Store the unit used at time of sale
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'xe_sale_variants'
        unique_together = ['sale', 'crop_variant']
    
    def __str__(self):
        return f"{self.sale.id} - {self.crop_variant.crop_variant}: {self.quantity} {self.unit}"
    
    def save(self, *args, **kwargs):
        # Auto-calculate total amount
        self.total_amount = self.quantity * self.amount_per_unit
        super().save(*args, **kwargs)

class Job(models.Model):
    JOB_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    job_name = models.CharField(max_length=255, verbose_name="Job Name")
    job_date = models.DateField(verbose_name="Job Date")
    job_status = models.CharField(max_length=20, choices=JOB_STATUS_CHOICES, default='pending')
    no_of_employees = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'xe_jobs'
        ordering = ['-created_at']
        verbose_name = 'Job'
        verbose_name_plural = 'Jobs'
    
    def __str__(self):
        return f"{self.job_name} - {self.job_date}"

class JobFarmSegment(models.Model):
    """Junction table for job and farm segments (many-to-many relationship)"""
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='job_farm_segments')
    farm_segment = models.ForeignKey(FarmSegment, on_delete=models.CASCADE, related_name='job_farm_segments')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'xe_job_farm_segments'
        unique_together = ['job', 'farm_segment']
    
    def __str__(self):
        return f"{self.job.job_name} - {self.farm_segment.farm_name}"

class JobEmployee(models.Model):
    """Junction table for job and employees (many-to-many relationship)"""
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='job_employees')
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='job_employees')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'xe_job_employees'
        unique_together = ['job', 'employee']
    
    def __str__(self):
        return f"{self.job.job_name} - {self.employee.name}"

class Expense(models.Model):
    CATEGORY_CHOICES = [
    ('Advance', 'Advance'),
    ('Food', 'Food'),
    ('Transport', 'Transport'),
    ('Donation and Give Away', 'Donation and Give Away'),
    ('Driver', 'Driver'),
    ('Miscellinious', 'Miscellinious'),
    ('Machine and Motor Repairs', 'Machine and Motor Repairs'),
    ('Jeep Maintenance', 'Jeep Maintenance'),
    ('Eb/Phone/Admin Exp', 'Eb/Phone/Admin Exp'),
    ('Fuel', 'Fuel'),
    ('Tree Samplings', 'Tree Samplings'),
    ('Farm Maintenance', 'Farm Maintenance'),
    ('Weekly Wages', 'Weekly Wages'),
]

    
    PAYMENT_MODE_CHOICES = [
        ('Cash', 'Cash'),
        ('Card', 'Card'),
        ('UPI', 'UPI'),
        ('Bank', 'Bank'),
        ('Cheque', 'Cheque'),
    ]
    
    expense_name = models.CharField(max_length=255)
    date = models.DateField()
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES)
    description = models.TextField(blank=True, null=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(Decimal('0.01'))])
    spent_by = models.CharField(max_length=255)
    mode_of_payment = models.CharField(max_length=100, choices=PAYMENT_MODE_CHOICES)
    expense_image_url = models.URLField(max_length=500, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'xe_expenses'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.expense_name} - {self.amount}"

class Wage(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='wages')
    effective_from = models.DateField(verbose_name="Effective From")
    effective_to = models.DateField(blank=True, null=True, verbose_name="Effective To")
    amount = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        validators=[MinValueValidator(Decimal('0.01'))],
        verbose_name="Wage Amount"
    )
    remarks = models.TextField(blank=True, null=True, verbose_name="Remarks")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'xe_wages'
        ordering = ['-effective_from', '-created_at']
        verbose_name = 'Wage'
        verbose_name_plural = 'Wages'
        # Ensure no overlapping wage periods for the same employee
        constraints = [
            models.CheckConstraint(
                check=models.Q(effective_to__isnull=True) | models.Q(effective_to__gte=models.F('effective_from')),
                name='wage_effective_to_gte_effective_from'
            )
        ]
    
    def __str__(self):
        return f"{self.employee.name} - ₹{self.amount} (from {self.effective_from})"
    
    def clean(self):
        from django.core.exceptions import ValidationError
        
        # Validate that effective_to is after effective_from if provided
        if self.effective_to and self.effective_from and self.effective_to < self.effective_from:
            raise ValidationError('Effective to date must be after effective from date.')
    
    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)
    
    @property
    def is_current(self):
        """Check if this wage record is currently active"""
        from datetime import date
        today = date.today()
        
        if self.effective_to:
            return self.effective_from <= today <= self.effective_to
        else:
            return self.effective_from <= today
    
    @classmethod
    def get_current_wage(cls, employee):
        """Get the current active wage for an employee"""
        from datetime import date
        today = date.today()

        return cls.objects.filter(
            employee=employee,
            effective_from__lte=today
        ).filter(
            models.Q(effective_to__isnull=True) | models.Q(effective_to__gte=today)
        ).order_by('-effective_from').first()
    

class AttendanceRecord(models.Model):
    """
    Single attendance record per date with JSON field containing all employee data
    """
    date = models.DateField(unique=True, verbose_name="Attendance Date")
    
    # JSON field to store array of employee attendance records
    # Structure: [{"employee_id": "1", "employee_name": "John", "status": 1, "wage_amount": 500.00}, ...]
    attendance_data = models.JSONField(
        default=list,
        verbose_name="Attendance Data",
        help_text="Array of employee attendance records"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        'Employee', 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='created_attendance_records',
        verbose_name="Created By"
    )
    
    class Meta:
        db_table = 'xe_attendance_records'
        ordering = ['-date']
        verbose_name = 'Attendance Record'
        verbose_name_plural = 'Attendance Records'
    
    def __str__(self):
        return f"Attendance for {self.date}"
    
    @property
    def total_employees(self):
        """Get total number of employees in this record"""
        return len(self.attendance_data)
    
    @property
    def total_present(self):
        """Get total number of employees present"""
        return len([emp for emp in self.attendance_data if emp.get('status') == 1])
    
    @property
    def total_absent(self):
        """Get total number of employees absent"""
        return len([emp for emp in self.attendance_data if emp.get('status') == 0])
    
    @property
    def total_half_day(self):
        """Get total number of employees on half day"""
        return len([emp for emp in self.attendance_data if emp.get('status') == 2])
    
    def get_employee_status(self, employee_id):
        """Get attendance status for specific employee"""
        for emp_data in self.attendance_data:
            if str(emp_data.get('employee_id')) == str(employee_id):
                return emp_data.get('status')
        return None
    
    def update_employee_status(self, employee_id, employee_name, status, wage_amount=None):
        """Update or add employee attendance status"""
        # Find existing employee record
        for i, emp_data in enumerate(self.attendance_data):
            if str(emp_data.get('employee_id')) == str(employee_id):
                # Update existing record
                self.attendance_data[i].update({
                    'employee_name': employee_name,
                    'status': status,
                    'wage_amount': float(wage_amount) if wage_amount else emp_data.get('wage_amount')
                })
                self.save()
                return
        
        # Add new employee record
        new_record = {
            'employee_id': str(employee_id),
            'employee_name': employee_name,
            'status': status,
            'wage_amount': float(wage_amount) if wage_amount else 0.0
        }
        self.attendance_data.append(new_record)
        self.save()
    
    def calculate_daily_wages_total(self):
        """Calculate total wages for this day based on present employees"""
        total = Decimal('0.00')
        for emp_data in self.attendance_data:
            if emp_data.get('status') == 1:  # Present
                wage_amount = emp_data.get('wage_amount', 0)
                total += Decimal(str(wage_amount))
            elif emp_data.get('status') == 2:  # Half Day
                wage_amount = emp_data.get('wage_amount', 0)
                total += Decimal(str(wage_amount)) / 2
        return total


class WeeklyWagePayment(models.Model):
    """
    Track weekly wage payments to employees
    """
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('partial', 'Partially Paid'),
        ('paid', 'Fully Paid'),
        ('cancelled', 'Cancelled'),
    ]
    
    PAYMENT_MODE_CHOICES = [
        ('Cash', 'Cash'),
        ('Card', 'Card'),
        ('UPI', 'UPI'),
        ('Bank', 'Bank'),
        ('Cheque', 'Cheque'),
    ]
    
    week_start_date = models.DateField(verbose_name="Week Start Date")
    week_end_date = models.DateField(verbose_name="Week End Date")
    employee = models.ForeignKey(
        'Employee', 
        on_delete=models.CASCADE, 
        related_name='weekly_wage_payments'
    )
    employee_name = models.CharField(
        max_length=255,
        default='Unknown',
        verbose_name="Employee Name",
        help_text="Cached employee name"
    )
    total_present_days = models.IntegerField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Total Present Days"
    )
    total_half_days = models.IntegerField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Total Half Days"
    )
    daily_wage_amount = models.DecimalField(
        max_digits=10, 
        decimal_places=2,
        verbose_name="Daily Wage Amount"
    )
    gross_amount = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Gross Amount"
    )
    advance_deduction = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Advance Deduction"
    )
    other_deductions = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Other Deductions"
    )
    total_deductions = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Total Deductions"
    )
    net_amount = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Net Amount"
    )
    paid_amount = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Amount Paid"
    )
    remaining_amount = models.DecimalField(
        max_digits=12, 
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name="Remaining Amount"
    )
    payment_status = models.CharField(
        max_length=20, 
        choices=PAYMENT_STATUS_CHOICES, 
        default='pending'
    )
    payment_mode = models.CharField(
        max_length=20, 
        choices=PAYMENT_MODE_CHOICES,
        blank=True,
        null=True
    )
    payment_date = models.DateTimeField(
        null=True, 
        blank=True,
        verbose_name="Payment Date"
    )
    payment_reference = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        verbose_name="Payment Reference"
    )
    remarks = models.TextField(
        blank=True, 
        null=True, 
        verbose_name="Payment Remarks"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Link to expense entry when payment is made
    expense_entry = models.OneToOneField(
        'Expense',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='wage_payment',
        verbose_name="Associated Expense Entry"
    )
    
    class Meta:
        db_table = 'xe_weekly_wage_payments'
        ordering = ['-week_start_date', 'employee_name']
        verbose_name = 'Weekly Wage Payment'
        verbose_name_plural = 'Weekly Wage Payments'
        # Ensure one payment record per employee per week
        constraints = [
            models.UniqueConstraint(
                fields=['week_start_date', 'employee'],
                name='unique_employee_weekly_payment'
            )
        ]
    
    def __str__(self):
        return f"{self.employee_name} - Week {self.week_start_date} (₹{self.net_amount})"
    
    def save(self, *args, **kwargs):
        # Cache employee name
        if not self.employee_name:
            self.employee_name = self.employee.name
            
        # Auto-calculate week end date (6 days from start)
        if self.week_start_date and not self.week_end_date:
            self.week_end_date = self.week_start_date + timedelta(days=6)
        
        # Auto-calculate totals
        self.total_deductions = self.advance_deduction + self.other_deductions
        self.net_amount = self.gross_amount - self.total_deductions
        self.remaining_amount = self.net_amount - self.paid_amount
        
        # Update payment status based on paid amount
        if self.paid_amount == Decimal('0.00'):
            self.payment_status = 'pending'
        elif self.paid_amount >= self.net_amount:
            self.payment_status = 'paid'
            if not self.payment_date:
                self.payment_date = timezone.now()
        else:
            self.payment_status = 'partial'
        
        super().save(*args, **kwargs)
    
    @classmethod
    def generate_weekly_payments(cls, week_start_date):
        """
        Generate weekly wage payment records for all employees for given week
        """
        from datetime import timedelta
        
        week_end_date = week_start_date + timedelta(days=6)
        week_dates = [week_start_date + timedelta(days=i) for i in range(7)]
        
        # Get attendance records for the week
        attendance_records = AttendanceRecord.objects.filter(
            date__in=week_dates
        )
        
        # Get all employees who have attendance in this week
        employees_in_week = {}
        for record in attendance_records:
            for emp_data in record.attendance_data:
                emp_id = emp_data['employee_id']
                if emp_id not in employees_in_week:
                    employees_in_week[emp_id] = {
                        'employee_name': emp_data['employee_name'],
                        'present_days': 0,
                        'half_days': 0,
                        'wage_amount': emp_data.get('wage_amount', 0)
                    }
                
                # Count attendance
                status = emp_data.get('status', 0)
                if status == 1:  # Present
                    employees_in_week[emp_id]['present_days'] += 1
                elif status == 2:  # Half Day
                    employees_in_week[emp_id]['half_days'] += 1
        
        payments_created = []
        for emp_id, emp_data in employees_in_week.items():
            try:
                employee = Employee.objects.get(id=emp_id)
            except Employee.DoesNotExist:
                continue
                
            # Check if payment already exists
            existing_payment = cls.objects.filter(
                week_start_date=week_start_date,
                employee=employee
            ).first()
            
            if existing_payment:
                continue
            
            # Calculate gross amount
            daily_wage = Decimal(str(emp_data['wage_amount']))
            present_days = emp_data['present_days']
            half_days = emp_data['half_days']
            
            gross_amount = (present_days * daily_wage) + (half_days * daily_wage / 2)
            
            payment = cls.objects.create(
                week_start_date=week_start_date,
                week_end_date=week_end_date,
                employee=employee,
                employee_name=emp_data['employee_name'],
                total_present_days=present_days,
                total_half_days=half_days,
                daily_wage_amount=daily_wage,
                gross_amount=gross_amount
            )
            payments_created.append(payment)
        
        return payments_created
    
    def make_payment(self, amount, payment_mode='Cash', reference='', remarks=''):
        """
        Process a payment for this wage record
        """
        from django.core.exceptions import ValidationError
        
        if amount <= 0:
            raise ValidationError("Payment amount must be greater than 0")
        
        if self.paid_amount + amount > self.net_amount:
            raise ValidationError("Payment amount exceeds remaining balance")
        
        self.paid_amount += amount
        self.payment_mode = payment_mode
        self.payment_reference = reference
        if remarks:
            self.remarks = remarks
        
        # Create expense entry for this payment
        if not self.expense_entry:
            from .models import Expense  # Adjust import as needed
            expense = Expense.objects.create(
                expense_name=f"Weekly Wages - {self.employee_name}",
                date=timezone.now().date(),
                category='Weekly Wages',
                description=f"Wage payment for week {self.week_start_date} to {self.week_end_date}",
                amount=amount,
                spent_by='Admin',
                mode_of_payment=payment_mode
            )
            self.expense_entry = expense
        else:
            # Update existing expense entry
            self.expense_entry.amount += amount
            self.expense_entry.save()
        
        self.save()
        return self


class WagePaymentTransaction(models.Model):
    """
    Track individual payment transactions for wage payments
    """
    TRANSACTION_TYPE_CHOICES = [
        ('payment', 'Payment'),
        ('refund', 'Refund'),
        ('adjustment', 'Adjustment'),
    ]
    
    wage_payment = models.ForeignKey(
        WeeklyWagePayment,
        on_delete=models.CASCADE,
        related_name='payment_transactions'
    )
    transaction_type = models.CharField(
        max_length=20,
        choices=TRANSACTION_TYPE_CHOICES,
        default='payment'
    )
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))]
    )
    payment_mode = models.CharField(
        max_length=20,
        choices=WeeklyWagePayment.PAYMENT_MODE_CHOICES
    )
    reference_number = models.CharField(
        max_length=255,
        blank=True,
        null=True
    )
    transaction_date = models.DateTimeField(default=timezone.now)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'xe_wage_payment_transactions'
        ordering = ['-transaction_date']
        verbose_name = 'Wage Payment Transaction'
        verbose_name_plural = 'Wage Payment Transactions'
    
    def __str__(self):
        return f"{self.wage_payment.employee_name} - {self.get_transaction_type_display()} ₹{self.amount}"


class AttendanceWeeklySummary(models.Model):
    """
    Weekly summary of attendance and wage calculations
    """
    week_start_date = models.DateField(
        unique=True,
        verbose_name="Week Start Date"
    )
    week_end_date = models.DateField(verbose_name="Week End Date")
    total_employees = models.IntegerField(
        default=0,
        verbose_name="Total Employees"
    )
    total_present_days = models.IntegerField(
        default=0,
        verbose_name="Total Present Days (Sum)"
    )
    total_half_days = models.IntegerField(
        default=0,
        verbose_name="Total Half Days (Sum)"
    )
    total_gross_wages = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Total Gross Wages"
    )
    total_deductions = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Total Deductions"
    )
    total_net_wages = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Total Net Wages"
    )
    total_paid_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Total Paid Amount"
    )
    total_pending_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        verbose_name="Total Pending Amount"
    )
    is_wages_paid = models.BooleanField(
        default=False,
        verbose_name="All Wages Paid"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'xe_attendance_weekly_summary'
        ordering = ['-week_start_date']
        verbose_name = 'Weekly Attendance Summary'
        verbose_name_plural = 'Weekly Attendance Summaries'
    
    def __str__(self):
        return f"Week {self.week_start_date} Summary - ₹{self.total_net_wages}"
    
    @classmethod
    def generate_summary(cls, week_start_date):
        """
        Generate or update weekly summary for given week
        """
        week_end_date = week_start_date + timedelta(days=6)
        
        # Get or create summary
        summary, created = cls.objects.get_or_create(
            week_start_date=week_start_date,
            defaults={'week_end_date': week_end_date}
        )
        
        # Calculate totals from weekly wage payments
        wage_payments = WeeklyWagePayment.objects.filter(
            week_start_date=week_start_date
        )
        
        summary.total_employees = wage_payments.count()
        summary.total_present_days = sum(payment.total_present_days for payment in wage_payments)
        summary.total_half_days = sum(payment.total_half_days for payment in wage_payments)
        summary.total_gross_wages = sum(payment.gross_amount for payment in wage_payments)
        summary.total_deductions = sum(payment.total_deductions for payment in wage_payments)
        summary.total_net_wages = sum(payment.net_amount for payment in wage_payments)
        summary.total_paid_amount = sum(payment.paid_amount for payment in wage_payments)
        summary.total_pending_amount = summary.total_net_wages - summary.total_paid_amount
        summary.is_wages_paid = summary.total_pending_amount == Decimal('0.00')
        
        summary.save()
        return summary

class BulkWagePayment(models.Model):
    """Model for storing bulk wage payments (pay all employees at once)"""
    PAYMENT_MODE_CHOICES = [
        ('Cash', 'Cash'),
        ('Bank Transfer', 'Bank Transfer'),
        ('UPI', 'UPI'),
        ('Cheque', 'Cheque'),
        ('Card', 'Card'),
    ]
    
    week_start_date = models.DateField()
    week_end_date = models.DateField()
    payment_date = models.DateTimeField(auto_now_add=True)
    
    # Store all employee payment details as JSON
    employee_payments = models.JSONField(default=list)  # Array of employee payment objects
    
    # Summary fields
    total_employees = models.IntegerField(default=0)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    
    # Payment details
    payment_mode = models.CharField(max_length=20, choices=PAYMENT_MODE_CHOICES, default='Cash')
    payment_reference = models.CharField(max_length=100, blank=True)
    remarks = models.TextField(blank=True)
    
    # Optional: Add expense tracking
    expense_category = models.CharField(max_length=50, default='Wages')
    
    # Audit fields
    paid_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'bulk_wage_payments'
        unique_together = ['week_start_date', 'week_end_date']
    
    def __str__(self):
        return f"Bulk Payment - Week {self.week_start_date} to {self.week_end_date}"
    
    @classmethod
    def create_bulk_payment(cls, week_start_date, employee_data, payment_mode='Cash', 
                           payment_reference='', remarks='', paid_by=None):
        """
        Create a bulk wage payment record
        
        employee_data format:
        [
            {
                'employee_id': '1',
                'employee_name': 'John Doe',
                'present_days': 5,
                'half_days': 1,
                'absent_days': 1,
                'daily_wage': 500.00,
                'total_wages': 2750.00,
                'attendance_details': {...}  # Optional: detailed attendance
            },
            ...
        ]
        """
        from .utils import get_week_dates
        
        week_dates = get_week_dates(week_start_date)
        week_end_date = week_dates[-1]
        
        total_amount = sum(emp['total_wages'] for emp in employee_data)
        
        bulk_payment = cls.objects.create(
            week_start_date=week_start_date,
            week_end_date=week_end_date,
            employee_payments=employee_data,
            total_employees=len(employee_data),
            total_amount=total_amount,
            payment_mode=payment_mode,
            payment_reference=payment_reference,
            remarks=remarks,
            paid_by=paid_by
        )
        
        return bulk_payment
